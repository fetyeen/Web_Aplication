document.addEventListener("DOMContentLoaded", function () {
    const users = JSON.parse(localStorage.getItem("users")) || [];
    const courses = JSON.parse(localStorage.getItem("courses")) || [];

    const studentSelect = document.getElementById("students");
    const hrElements = document.querySelectorAll(".courses .hr1");

    // Заполнение селекта студентов
    users.forEach(user => {
        const option = document.createElement("option");
        option.value = user.email;
        option.textContent = `${user.firstName} ${user.lastName}`;
        studentSelect.appendChild(option);
    });

    studentSelect.addEventListener("change", function () {
        const selectedEmail = this.value;

        // Удалить старые курсы (если уже были вставлены)
        document.querySelectorAll(".course-entry").forEach(el => el.remove());

        const filteredCourses = courses.filter(course =>
            Array.isArray(course.students) && course.students.includes(selectedEmail)
        );

        const displayCount = Math.min(filteredCourses.length, hrElements.length);

        for (let i = 0; i < displayCount; i++) {
            const course = filteredCourses[i];

            const courseInfo = document.createElement("div");
            courseInfo.classList.add("course-entry");
            courseInfo.innerHTML = `
              <div class="content" style="font-size: 12px; line-height: 1.2; margin-bottom: 4px;">
                <h2 style="font-size: 14px; margin: 2px 0;">${course.name}</h2>
                <h3 style="font-size: 12px; margin: 2px 0;">${course.date}</h3>
              </div>
            `;

            hrElements[i].parentNode.insertBefore(courseInfo, hrElements[i]);
        }
    });
});