function updateCourseSelects() {
    const courses = JSON.parse(localStorage.getItem("courses")) || [];

    // Находим все элементы select с id="course"
    const courseSelects = document.querySelectorAll('select[id="course"]');

    // Обновляем каждый select
    courseSelects.forEach(select => {
        // Очищаем текущие опции
        select.innerHTML = '';

        // Добавляем новые опции
        courses.forEach(course => {
            const option = document.createElement('option');
            option.value = course;
            option.textContent = course;
            select.appendChild(option);
        });
    });
}

// Обработчик нажатия кнопки "Add Course"
document.getElementById("add_course").addEventListener("click", function () {
    const courseName = document.getElementById("name_course").value.trim();

    if (courseName) {
        // Получаем текущие курсы из локального хранилища
        const courses = JSON.parse(localStorage.getItem("courses")) || [];

        // Добавляем новый курс в массив
        courses.push(courseName);

        // Сохраняем обновленный список курсов в локальное хранилище
        localStorage.setItem("courses", JSON.stringify(courses));

        alert("Course added successfully!");

        // Обновляем все селекты с курсами на странице
        updateCourseSelects();

        // Очищаем поле ввода
        document.getElementById("name_course").value = "";
    } else {
        alert("Please enter a course name.");
    }
});