// Функция для загрузки курсов в селект
function loadCourses() {
    const courses = JSON.parse(localStorage.getItem("courses")) || [];
    const courseSelect = document.getElementById("course");

    // Очищаем селект
    courseSelect.innerHTML = '';

    // Добавляем курсы в селект
    courses.forEach(course => {
        const option = document.createElement('option');
        option.value = course;
        option.textContent = course;
        courseSelect.appendChild(option);
    });
}

// Функция для удаления выбранного курса
document.getElementById("delete_course").addEventListener("click", function() {
    const courseSelect = document.getElementById("course");
    const selectedCourse = courseSelect.value;

    // Получаем список курсов из localStorage
    let courses = JSON.parse(localStorage.getItem("courses")) || [];

    // Находим индекс выбранного курса
    const courseIndex = courses.indexOf(selectedCourse);

    if (courseIndex !== -1) {
        // Удаляем выбранный курс
        courses.splice(courseIndex, 1);

        // Сохраняем обновленный список курсов обратно в localStorage
        localStorage.setItem("courses", JSON.stringify(courses));

        alert("Course deleted successfully!");

        // Перезагружаем селект с обновленным списком курсов
        loadCourses();
    } else {
        alert("Course not found.");
    }
});

// Загружаем курсы при загрузке страницы
window.addEventListener("load", loadCourses);