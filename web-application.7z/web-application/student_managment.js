document.addEventListener("DOMContentLoaded", function () {
    const users = JSON.parse(localStorage.getItem("users")) || [];

    const select = document.getElementById("students");
    users.forEach(user => {
        const option = document.createElement("option");
        option.value = user.email;
        option.textContent = `${user.firstName} ${user.lastName}`;
        select.appendChild(option);
    });
});