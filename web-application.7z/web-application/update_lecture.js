function loadLecturers() {
    const lecturers = JSON.parse(localStorage.getItem("lecturers")) || [];
    const lecturersSelect = document.getElementById("lecturers");

    // Очищаем селект
    lecturersSelect.innerHTML = '';

    // Добавляем лекторов в селект
    lecturers.forEach(lecturer => {
        const option = document.createElement('option');
        option.value = lecturer;
        option.textContent = lecturer;
        lecturersSelect.appendChild(option);
    });
}

// Загружаем лекторов при загрузке страницы
window.addEventListener("load", loadLecturers);