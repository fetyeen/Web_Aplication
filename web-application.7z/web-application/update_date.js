function loadDates() {
    const dates = JSON.parse(localStorage.getItem("dates")) || [];
    const select = document.getElementById("dates");

    if (!select) return;

    select.innerHTML = ""; // Очистить список

    dates.forEach(date => {
        const option = document.createElement("option");
        option.value = date;
        option.textContent = date;
        select.appendChild(option);
    });
}

window.addEventListener("load", loadDates);