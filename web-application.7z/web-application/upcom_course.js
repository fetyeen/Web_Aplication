const courses = JSON.parse(localStorage.getItem("courses")) || [];

  const hrElements = document.querySelectorAll(".courses .hr1");
  const displayCount = Math.min(courses.length, hrElements.length);

  for (let i = 0; i < displayCount; i++) {
    const course = courses[i];

    const courseInfo = document.createElement("div");
    courseInfo.classList.add("course-entry");
    courseInfo.innerHTML = `
      <div class="content" style="font-size: 12px; line-height: 1.2; margin-bottom: 4px;">
        <h2 style="font-size: 14px; margin: 2px 0;">${course.name}</h2>
        <h3 style="font-size: 12px; margin: 2px 0;">${course.date}</h3>
      </div>
    `;

    hrElements[i].parentNode.insertBefore(courseInfo, hrElements[i]);
  }