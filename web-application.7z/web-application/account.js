document.addEventListener("DOMContentLoaded", function () {
    const user = JSON.parse(localStorage.getItem("loggedUser"));

    if (user) {
        document.getElementById("user_name").textContent = user.firstName;
        document.getElementById("surname").textContent = user.lastName;
        document.getElementById("user_email_details").textContent = user.email;
    } else {
        alert("No user is logged in.");
        window.location.href = "log.html"; // отправляем обратно на логин
    }
});