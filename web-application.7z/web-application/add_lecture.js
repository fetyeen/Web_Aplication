// Функция для добавления лектора
document.getElementById("add_lecture").addEventListener("click", function() {
    const nameLecturer = document.getElementById("name_lecturer").value.trim();
    const surnameLecturer = document.getElementById("surname_lecturer").value.trim();

    if (nameLecturer && surnameLecturer) {
        const fullName = `${nameLecturer} ${surnameLecturer}`;
        
        // Получаем список лекторов из localStorage
        let lecturers = JSON.parse(localStorage.getItem("lecturers")) || [];

        // Добавляем нового лектора
        lecturers.push(fullName);

        // Сохраняем обновленный список лекторов в localStorage
        localStorage.setItem("lecturers", JSON.stringify(lecturers));

        alert("Lecturer added successfully!");

        // Очищаем поля ввода
        document.getElementById("name_lecturer").value = '';
        document.getElementById("surname_lecturer").value = '';

        // Обновляем селект с лекторами
        loadLecturers();
    } else {
        alert("Please enter both name and surname.");
    }
});

// Функция для загрузки лекторов в селект
function loadLecturers() {
    const lecturers = JSON.parse(localStorage.getItem("lecturers")) || [];
    const lecturersSelect = document.getElementById("lecturers");

    // Очищаем селект
    lecturersSelect.innerHTML = '';

    // Добавляем лекторов в селект
    lecturers.forEach(lecturer => {
        const option = document.createElement('option');
        option.value = lecturer;
        option.textContent = lecturer;
        lecturersSelect.appendChild(option);
    });
}

// Загружаем лекторов при загрузке страницы
window.addEventListener("load", loadLecturers);