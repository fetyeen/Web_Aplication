// Загрузка списка дат при загрузке страницы
window.addEventListener("load", function () {
    const dateSelect = document.getElementById("date");
    const dates = JSON.parse(localStorage.getItem("dates")) || [];

    // Очистить селект
    dateSelect.innerHTML = "";

    // Добавить опции
    dates.forEach(date => {
        const option = document.createElement("option");
        option.value = date;
        option.textContent = date;
        dateSelect.appendChild(option);
    });
});

// Удаление выбранной даты
document.getElementById("delete_data").addEventListener("click", function () {
    const selectedDate = document.getElementById("date").value;
    let dates = JSON.parse(localStorage.getItem("dates")) || [];

    // Фильтруем даты, исключая выбранную
    const updatedDates = dates.filter(date => date !== selectedDate);

    // Сохраняем обновлённый список
    localStorage.setItem("dates", JSON.stringify(updatedDates));

    alert("Date deleted successfully.");
    location.reload(); // Перезагрузка страницы для обновления селекта
});
