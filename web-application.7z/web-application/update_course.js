function updateCourseSelect() {
    const courses = JSON.parse(localStorage.getItem("courses")) || [];

    const courseSelect = document.getElementById("course");

    // Очищаем текущие опции в селекте
    courseSelect.innerHTML = '';

    // Добавляем новые курсы
    courses.forEach(course => {
        const option = document.createElement('option');
        option.value = course;
        option.textContent = course;
        courseSelect.appendChild(option);
    });
}

// Обновляем селект с курсами при загрузке страницы
window.addEventListener("load", updateCourseSelect);