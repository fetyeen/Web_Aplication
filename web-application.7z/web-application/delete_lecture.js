function loadLecturers() {
    const lecturers = JSON.parse(localStorage.getItem("lecturers")) || [];
    const select = document.getElementById("lecture");

    // Очищаем select
    select.innerHTML = "";

    // Добавляем лекторов
    lecturers.forEach((lecturer) => {
        const option = document.createElement("option");
        option.value = lecturer;
        option.textContent = lecturer;
        select.appendChild(option);
    });
}

// Удаление выбранного лектора
document.getElementById("delete_lecture").addEventListener("click", function () {
    const select = document.getElementById("lecture");
    const selectedLecturer = select.value;

    if (!selectedLecturer) {
        alert("Please select a lecturer to delete.");
        return;
    }

    let lecturers = JSON.parse(localStorage.getItem("lecturers")) || [];

    // Фильтруем список, исключая выбранного лектора
    lecturers = lecturers.filter(lecturer => lecturer !== selectedLecturer);

    // Сохраняем обновлённый список
    localStorage.setItem("lecturers", JSON.stringify(lecturers));

    // Перезагружаем select
    loadLecturers();

    alert(`Lecturer "${selectedLecturer}" deleted successfully.`);
});

// Загружаем список при загрузке страницы
window.addEventListener("load", loadLecturers);