document.getElementById("Add").addEventListener("click", function () {
  const courseName = document.getElementById("course").value; // исправлено с course_name
  const lecturer = document.getElementById("lecturers").value;
  const date = document.getElementById("dates").value;

  if (!courseName) {
      alert("Please select a course.");
      return;
  }

  const newCourse = {
      name: courseName,
      lecturer: lecturer,
      date: date
  };

  const courses = JSON.parse(localStorage.getItem("courses")) || [];
  courses.push(newCourse);
  localStorage.setItem("courses", JSON.stringify(courses));

  // Переход на страницу подтверждения
  window.location.href = "add.html";
});