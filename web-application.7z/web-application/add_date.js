document.getElementById("addow_date").addEventListener("click", function () {
    const dateInput = document.getElementById("date").value;
    if (!dateInput) {
        alert("Please enter a date.");
        return;
    }

    // Загружаем текущие даты из localStorage
    let dates = JSON.parse(localStorage.getItem("dates")) || [];

    // Проверка на дубликаты
    if (dates.includes(dateInput)) {
        alert("This date already exists.");
        return;
    }

    // Добавляем дату и сохраняем
    dates.push(dateInput);
    localStorage.setItem("dates", JSON.stringify(dates));

    alert("Date added successfully.");
});