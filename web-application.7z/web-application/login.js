document.getElementById("log").addEventListener("click", function (e) {
    e.preventDefault();

    const emailInput = document.getElementById("user_email").value.trim();
    const passwordInput = document.getElementById("password").value.trim();

    if (!emailInput || !passwordInput) {
        alert("Please enter both email and password.");
        return;
    }

    const users = JSON.parse(localStorage.getItem("users")) || [];

    const foundUser = users.find(user => user.email === emailInput && user.password === passwordInput);

    // Проверка на администратора
    const adminEmail = "admin";
    const adminPassword = "1234";

    if (emailInput === adminEmail && passwordInput === adminPassword) {
        alert("Administrator login successful!");
        window.location.href = "main2.html";
    } else if (foundUser) {
        alert("Login successful!");
        // Сохраняем активного пользователя для account.js
        localStorage.setItem("loggedUser", JSON.stringify(foundUser));
        window.location.href = "main.html"; // Переход на главную страницу
    } else {
        alert("Invalid login or password.");
    }
});