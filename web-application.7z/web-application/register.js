document.getElementById("sign").addEventListener("click", function (e) {
    e.preventDefault();

    const firstName = document.getElementById("user_name").value.trim();
    const lastName = document.getElementById("surname").value.trim();
    const email = document.getElementById("user_email").value.trim();
    const password = document.getElementById("password").value;

    if (!firstName || !lastName || !email || !password) {
        alert("Please fill out all fields.");
        return;
    }

    const users = JSON.parse(localStorage.getItem("users")) || [];

    const exists = users.some(user => user.email === email);
    if (exists) {
        alert("An account with this email already exists.");
        return;
    }

    const newUser = {
        firstName: firstName,
        lastName: lastName,
        email: email,
        password: password
    };

    users.push(newUser);
    localStorage.setItem("users", JSON.stringify(users));

    alert("Registration successful!");
    window.location.href = "log.html";
});